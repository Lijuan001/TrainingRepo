import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-openpanel',
  templateUrl: './one-openpanel.component.html',
  styleUrls: ['./one-openpanel.component.scss']
})
export class OneOpenpanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
