export class Song{
    artistName:string;
    collectionName:string;
    artworkUrl100:string;
}