import { Song } from './song';

export class Album{
    resultCount:number;
    results:Song[];
}